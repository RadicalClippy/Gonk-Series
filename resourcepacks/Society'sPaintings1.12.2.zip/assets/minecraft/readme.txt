optimized for MCPatcher!! Download it!

http://www.minecraftforum.net/topic/1496369-15-147update-38-mcpatcher-hd-fix-301-245-03/